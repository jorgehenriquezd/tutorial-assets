export const Diseases = [
  "Gripe Común",
  "Resfriado",
  "Gastroenteritis",
  "Conjuntivitis",
  "Otitis Media",
  "Faringitis",
  "Amigdalitis",
  "Dermatitis Atópica",
  "Cistitis",
  "Migraña"
];